# Case Study 4 - Log File Analyzer

file_path = "CS4.txt"

# -------- Task 1: Basic File Reading --------
with open(file_path, "r") as file:
    content = file.read()

lines = content.splitlines()

print("Total number of lines:", len(lines))

print("\nFirst 2 lines:")
for line in lines[:2]:
    print(line)

print("\nLast 2 lines:")
for line in lines[-2:]:
    print(line)

# Using readline()
print("\nUsing readline():")
with open(file_path, "r") as file:
    print(file.readline(), end="")
    print(file.readline(), end="")

# Using readlines()
print("\nUsing readlines():")
with open(file_path, "r") as file:
    all_lines = file.readlines()
    print("Total lines (readlines):", len(all_lines))


# -------- Task 2: Log Classification --------
log_counts = {"INFO": 0, "WARNING": 0, "ERROR": 0}

for line in lines:
    words = line.split()
    if "INFO" in words:
        log_counts["INFO"] += 1
    if "WARNING" in words:
        log_counts["WARNING"] += 1
    if "ERROR" in words:
        log_counts["ERROR"] += 1

print("\nLog Counts:")
print(log_counts)


# -------- Task 3: Write Filtered Files --------
info_lines = []
warning_lines = []
error_lines = []

for line in lines:
    words = line.split()
    if "INFO" in words:
        info_lines.append(line + "\n")
    if "WARNING" in words:
        warning_lines.append(line + "\n")
    if "ERROR" in words:
        error_lines.append(line + "\n")

with open("info_logs.txt", "w") as f:
    f.writelines(info_lines)

with open("warning_logs.txt", "w") as f:
    f.writelines(warning_lines)

with open("error_logs.txt", "w") as f:
    f.writelines(error_lines)

print("\nFiltered files created successfully.")


# -------- Task 4: Search Feature --------
keyword = input("\nEnter keyword to search (e.g., ERROR): ")

matched_lines = []
for line in lines:
    if keyword in line:
        matched_lines.append(line)

print("\nMatching lines:")
for line in matched_lines:
    print(line)

with open("search_result.txt", "w") as f:
    for line in matched_lines:
        f.write(line + "\n")

print("Search results saved to search_result.txt")


# -------- File Pointer (seek) Operations --------
with open(file_path, "r") as file:

    print("\n--- File Pointer Operations ---")

    # First 50 characters
    print("\nFirst 50 characters:")
    print(file.read(50))

    # Beginning
    file.seek(0)
    print("\nAfter seek(0) - Beginning:")
    print(file.read(50))

    # Middle
    file.seek(0, 2)  # move to end
    size = file.tell()
    file.seek(size // 2)

    print("\nAfter seek to middle:")
    print(file.read(50))

    # Last 100 characters
    file.seek(0)
    data = file.read()

    print("\nLast 100 characters:")
    print(data[-100:])